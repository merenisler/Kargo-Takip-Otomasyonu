﻿namespace KargoTakip
{
    partial class KargoGonder
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KargoGonder));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.radioBtnEv = new System.Windows.Forms.RadioButton();
            this.radioBtnIs = new System.Windows.Forms.RadioButton();
            this.radioBtnDiger = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbBxIl = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbBxIlce = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbBxMahalle = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbBxCadde = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbBxSokak = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.richTxtBoxAdres = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtBxTc = new System.Windows.Forms.TextBox();
            this.txtBxAdSoyad = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtBxTelefon = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.btnYazdir = new System.Windows.Forms.Button();
            this.radioBtnKurumsal = new System.Windows.Forms.RadioButton();
            this.radioBtnBireysel = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBxVg = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBxVg2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.radioBtnKurumsal2 = new System.Windows.Forms.RadioButton();
            this.radioBtnBireysel2 = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.txtBxTelefon2 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtBxAdSoyad2 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtBxTc2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.richTxtBoxAdres2 = new System.Windows.Forms.RichTextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.cmbBxSokak2 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cmbBxCadde2 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cmbBxMahalle2 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.cmbBxIlce2 = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cmbBxIl2 = new System.Windows.Forms.ComboBox();
            this.radioBtnDiger2 = new System.Windows.Forms.RadioButton();
            this.radioBtnIs2 = new System.Windows.Forms.RadioButton();
            this.radioBtnEv2 = new System.Windows.Forms.RadioButton();
            this.label27 = new System.Windows.Forms.Label();
            this.txtBxEmail = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtBxEmail2 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.txtBxAgirlik = new System.Windows.Forms.TextBox();
            this.txtBxEn = new System.Windows.Forms.TextBox();
            this.txtBxYukseklik = new System.Windows.Forms.TextBox();
            this.txtBxBoy = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.btnHesapla = new System.Windows.Forms.Button();
            this.txtBxDesi = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtBxFiyat = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.cmbBxOdemeBilgisi = new System.Windows.Forms.ComboBox();
            this.cmbBxKargoTipi = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.btnOnayla = new System.Windows.Forms.Button();
            this.btnİptal = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.checkBxKorumali = new System.Windows.Forms.CheckBox();
            this.checkBxSigortali = new System.Windows.Forms.CheckBox();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.btnAlanlarıTemizle = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(2, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Adres Tipi: ";
            // 
            // radioBtnEv
            // 
            this.radioBtnEv.AutoSize = true;
            this.radioBtnEv.Checked = true;
            this.radioBtnEv.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.radioBtnEv.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioBtnEv.Location = new System.Drawing.Point(3, 3);
            this.radioBtnEv.Name = "radioBtnEv";
            this.radioBtnEv.Size = new System.Drawing.Size(55, 29);
            this.radioBtnEv.TabIndex = 4;
            this.radioBtnEv.TabStop = true;
            this.radioBtnEv.Text = "Ev";
            this.radioBtnEv.UseVisualStyleBackColor = true;
            // 
            // radioBtnIs
            // 
            this.radioBtnIs.AutoSize = true;
            this.radioBtnIs.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.radioBtnIs.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioBtnIs.Location = new System.Drawing.Point(63, 3);
            this.radioBtnIs.Name = "radioBtnIs";
            this.radioBtnIs.Size = new System.Drawing.Size(46, 29);
            this.radioBtnIs.TabIndex = 5;
            this.radioBtnIs.Text = "İş";
            this.radioBtnIs.UseVisualStyleBackColor = true;
            // 
            // radioBtnDiger
            // 
            this.radioBtnDiger.AutoSize = true;
            this.radioBtnDiger.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.radioBtnDiger.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioBtnDiger.Location = new System.Drawing.Point(115, 3);
            this.radioBtnDiger.Name = "radioBtnDiger";
            this.radioBtnDiger.Size = new System.Drawing.Size(81, 29);
            this.radioBtnDiger.TabIndex = 6;
            this.radioBtnDiger.Text = "Diğer";
            this.radioBtnDiger.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F);
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(199, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(221, 47);
            this.label3.TabIndex = 7;
            this.label3.Text = "Alıcı Bilgileri";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F);
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(672, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 468);
            this.label4.TabIndex = 8;
            this.label4.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|";
            // 
            // cmbBxIl
            // 
            this.cmbBxIl.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxIl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbBxIl.FormattingEnabled = true;
            this.cmbBxIl.Location = new System.Drawing.Point(143, 111);
            this.cmbBxIl.Name = "cmbBxIl";
            this.cmbBxIl.Size = new System.Drawing.Size(194, 32);
            this.cmbBxIl.TabIndex = 1;
            this.cmbBxIl.SelectedIndexChanged += new System.EventHandler(this.cmbBxIl_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(4, 111);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 32);
            this.label6.TabIndex = 11;
            this.label6.Text = "İl:";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(4, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(132, 32);
            this.label7.TabIndex = 12;
            this.label7.Text = "İlçe:";
            // 
            // cmbBxIlce
            // 
            this.cmbBxIlce.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxIlce.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbBxIlce.FormattingEnabled = true;
            this.cmbBxIlce.Location = new System.Drawing.Point(143, 153);
            this.cmbBxIlce.Name = "cmbBxIlce";
            this.cmbBxIlce.Size = new System.Drawing.Size(194, 32);
            this.cmbBxIlce.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(4, 196);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(132, 32);
            this.label8.TabIndex = 14;
            this.label8.Text = "Mahalle:";
            // 
            // cmbBxMahalle
            // 
            this.cmbBxMahalle.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxMahalle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbBxMahalle.FormattingEnabled = true;
            this.cmbBxMahalle.Location = new System.Drawing.Point(143, 197);
            this.cmbBxMahalle.Name = "cmbBxMahalle";
            this.cmbBxMahalle.Size = new System.Drawing.Size(194, 32);
            this.cmbBxMahalle.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(4, 239);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 32);
            this.label9.TabIndex = 16;
            this.label9.Text = "Cadde:";
            // 
            // cmbBxCadde
            // 
            this.cmbBxCadde.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxCadde.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbBxCadde.FormattingEnabled = true;
            this.cmbBxCadde.Location = new System.Drawing.Point(143, 241);
            this.cmbBxCadde.Name = "cmbBxCadde";
            this.cmbBxCadde.Size = new System.Drawing.Size(194, 32);
            this.cmbBxCadde.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(4, 282);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 32);
            this.label10.TabIndex = 18;
            this.label10.Text = "Sokak:";
            // 
            // cmbBxSokak
            // 
            this.cmbBxSokak.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxSokak.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbBxSokak.FormattingEnabled = true;
            this.cmbBxSokak.Location = new System.Drawing.Point(143, 283);
            this.cmbBxSokak.Name = "cmbBxSokak";
            this.cmbBxSokak.Size = new System.Drawing.Size(194, 32);
            this.cmbBxSokak.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(4, 325);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(140, 32);
            this.label11.TabIndex = 20;
            this.label11.Text = "Açık Adres:";
            // 
            // richTxtBoxAdres
            // 
            this.richTxtBoxAdres.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTxtBoxAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.richTxtBoxAdres.Location = new System.Drawing.Point(143, 327);
            this.richTxtBoxAdres.Name = "richTxtBoxAdres";
            this.richTxtBoxAdres.Size = new System.Drawing.Size(339, 130);
            this.richTxtBoxAdres.TabIndex = 6;
            this.richTxtBoxAdres.Text = "";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(340, 111);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 32);
            this.label13.TabIndex = 23;
            this.label13.Text = "TC No:";
            // 
            // txtBxTc
            // 
            this.txtBxTc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.txtBxTc.Location = new System.Drawing.Point(467, 111);
            this.txtBxTc.Name = "txtBxTc";
            this.txtBxTc.Size = new System.Drawing.Size(194, 31);
            this.txtBxTc.TabIndex = 7;
            this.txtBxTc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxTc_KeyPress);
            // 
            // txtBxAdSoyad
            // 
            this.txtBxAdSoyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.txtBxAdSoyad.Location = new System.Drawing.Point(467, 154);
            this.txtBxAdSoyad.Name = "txtBxAdSoyad";
            this.txtBxAdSoyad.Size = new System.Drawing.Size(194, 31);
            this.txtBxAdSoyad.TabIndex = 8;
            this.txtBxAdSoyad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxAdSoyad_KeyPress);
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(341, 154);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(123, 32);
            this.label14.TabIndex = 26;
            this.label14.Text = "Ad/Soyad:";
            // 
            // txtBxTelefon
            // 
            this.txtBxTelefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.txtBxTelefon.Location = new System.Drawing.Point(467, 198);
            this.txtBxTelefon.Name = "txtBxTelefon";
            this.txtBxTelefon.Size = new System.Drawing.Size(194, 31);
            this.txtBxTelefon.TabIndex = 9;
            this.txtBxTelefon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxTelefon_KeyPress);
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(340, 198);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(108, 32);
            this.label15.TabIndex = 28;
            this.label15.Text = "Telefon:";
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F);
            this.label24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label24.Location = new System.Drawing.Point(868, 9);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(310, 47);
            this.label24.TabIndex = 34;
            this.label24.Text = "Gönderici Bilgileri";
            // 
            // btnYazdir
            // 
            this.btnYazdir.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnYazdir.FlatAppearance.BorderSize = 0;
            this.btnYazdir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYazdir.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.btnYazdir.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnYazdir.Location = new System.Drawing.Point(1208, 485);
            this.btnYazdir.Name = "btnYazdir";
            this.btnYazdir.Size = new System.Drawing.Size(152, 42);
            this.btnYazdir.TabIndex = 53;
            this.btnYazdir.Text = "Yazdır";
            this.btnYazdir.UseVisualStyleBackColor = false;
            this.btnYazdir.Click += new System.EventHandler(this.btnYazdir_Click);
            // 
            // radioBtnKurumsal
            // 
            this.radioBtnKurumsal.AutoSize = true;
            this.radioBtnKurumsal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBtnKurumsal.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioBtnKurumsal.Location = new System.Drawing.Point(108, 3);
            this.radioBtnKurumsal.Name = "radioBtnKurumsal";
            this.radioBtnKurumsal.Size = new System.Drawing.Size(113, 29);
            this.radioBtnKurumsal.TabIndex = 56;
            this.radioBtnKurumsal.Text = "Kurumsal";
            this.radioBtnKurumsal.UseVisualStyleBackColor = true;
            this.radioBtnKurumsal.CheckedChanged += new System.EventHandler(this.radioBtnKurumsal_CheckedChanged);
            // 
            // radioBtnBireysel
            // 
            this.radioBtnBireysel.AutoSize = true;
            this.radioBtnBireysel.Checked = true;
            this.radioBtnBireysel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBtnBireysel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioBtnBireysel.Location = new System.Drawing.Point(2, 3);
            this.radioBtnBireysel.Name = "radioBtnBireysel";
            this.radioBtnBireysel.Size = new System.Drawing.Size(99, 29);
            this.radioBtnBireysel.TabIndex = 55;
            this.radioBtnBireysel.TabStop = true;
            this.radioBtnBireysel.Text = "Bireysel";
            this.radioBtnBireysel.UseVisualStyleBackColor = true;
            this.radioBtnBireysel.CheckedChanged += new System.EventHandler(this.radioBtnBireysel_CheckedChanged);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(338, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 32);
            this.label1.TabIndex = 54;
            this.label1.Text = "Alıcı Tipi: ";
            // 
            // txtBxVg
            // 
            this.txtBxVg.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.txtBxVg.Location = new System.Drawing.Point(467, 242);
            this.txtBxVg.Name = "txtBxVg";
            this.txtBxVg.Size = new System.Drawing.Size(194, 31);
            this.txtBxVg.TabIndex = 10;
            this.txtBxVg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxVg_KeyPress);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(343, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 32);
            this.label5.TabIndex = 57;
            this.label5.Text = "VG No:";
            // 
            // txtBxVg2
            // 
            this.txtBxVg2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.txtBxVg2.Location = new System.Drawing.Point(1149, 242);
            this.txtBxVg2.Name = "txtBxVg2";
            this.txtBxVg2.Size = new System.Drawing.Size(194, 31);
            this.txtBxVg2.TabIndex = 21;
            this.txtBxVg2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxVg2_KeyPress);
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(1025, 243);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 32);
            this.label12.TabIndex = 84;
            this.label12.Text = "VG No:";
            // 
            // radioBtnKurumsal2
            // 
            this.radioBtnKurumsal2.AutoSize = true;
            this.radioBtnKurumsal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBtnKurumsal2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioBtnKurumsal2.Location = new System.Drawing.Point(105, 3);
            this.radioBtnKurumsal2.Name = "radioBtnKurumsal2";
            this.radioBtnKurumsal2.Size = new System.Drawing.Size(113, 29);
            this.radioBtnKurumsal2.TabIndex = 83;
            this.radioBtnKurumsal2.Text = "Kurumsal";
            this.radioBtnKurumsal2.UseVisualStyleBackColor = true;
            this.radioBtnKurumsal2.CheckedChanged += new System.EventHandler(this.radioBtnKurumsal2_CheckedChanged);
            // 
            // radioBtnBireysel2
            // 
            this.radioBtnBireysel2.AutoSize = true;
            this.radioBtnBireysel2.Checked = true;
            this.radioBtnBireysel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBtnBireysel2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioBtnBireysel2.Location = new System.Drawing.Point(4, 3);
            this.radioBtnBireysel2.Name = "radioBtnBireysel2";
            this.radioBtnBireysel2.Size = new System.Drawing.Size(99, 29);
            this.radioBtnBireysel2.TabIndex = 82;
            this.radioBtnBireysel2.TabStop = true;
            this.radioBtnBireysel2.Text = "Bireysel";
            this.radioBtnBireysel2.UseVisualStyleBackColor = true;
            this.radioBtnBireysel2.CheckedChanged += new System.EventHandler(this.radioBtnBireysel2_CheckedChanged);
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(1020, 74);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(120, 32);
            this.label16.TabIndex = 81;
            this.label16.Text = "Gönderici Tipi: ";
            // 
            // txtBxTelefon2
            // 
            this.txtBxTelefon2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.txtBxTelefon2.Location = new System.Drawing.Point(1149, 198);
            this.txtBxTelefon2.Name = "txtBxTelefon2";
            this.txtBxTelefon2.Size = new System.Drawing.Size(194, 31);
            this.txtBxTelefon2.TabIndex = 20;
            this.txtBxTelefon2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxTelefon2_KeyPress);
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label17.Location = new System.Drawing.Point(1022, 198);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(108, 32);
            this.label17.TabIndex = 79;
            this.label17.Text = "Telefon:";
            // 
            // txtBxAdSoyad2
            // 
            this.txtBxAdSoyad2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.txtBxAdSoyad2.Location = new System.Drawing.Point(1149, 154);
            this.txtBxAdSoyad2.Name = "txtBxAdSoyad2";
            this.txtBxAdSoyad2.Size = new System.Drawing.Size(194, 31);
            this.txtBxAdSoyad2.TabIndex = 19;
            this.txtBxAdSoyad2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxAdSoyad2_KeyPress);
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label18.Location = new System.Drawing.Point(1023, 154);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(123, 32);
            this.label18.TabIndex = 77;
            this.label18.Text = "Ad/Soyad:";
            // 
            // txtBxTc2
            // 
            this.txtBxTc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.txtBxTc2.Location = new System.Drawing.Point(1149, 111);
            this.txtBxTc2.Name = "txtBxTc2";
            this.txtBxTc2.Size = new System.Drawing.Size(194, 31);
            this.txtBxTc2.TabIndex = 18;
            this.txtBxTc2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxTc2_KeyPress);
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label19.Location = new System.Drawing.Point(1022, 111);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(99, 32);
            this.label19.TabIndex = 75;
            this.label19.Text = "TC No:";
            // 
            // richTxtBoxAdres2
            // 
            this.richTxtBoxAdres2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTxtBoxAdres2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.richTxtBoxAdres2.Location = new System.Drawing.Point(828, 327);
            this.richTxtBoxAdres2.Name = "richTxtBoxAdres2";
            this.richTxtBoxAdres2.Size = new System.Drawing.Size(339, 130);
            this.richTxtBoxAdres2.TabIndex = 17;
            this.richTxtBoxAdres2.Text = "";
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label20.Location = new System.Drawing.Point(689, 325);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(140, 32);
            this.label20.TabIndex = 73;
            this.label20.Text = "Açık Adres:";
            // 
            // cmbBxSokak2
            // 
            this.cmbBxSokak2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxSokak2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbBxSokak2.FormattingEnabled = true;
            this.cmbBxSokak2.Location = new System.Drawing.Point(828, 283);
            this.cmbBxSokak2.Name = "cmbBxSokak2";
            this.cmbBxSokak2.Size = new System.Drawing.Size(194, 32);
            this.cmbBxSokak2.TabIndex = 16;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label21.Location = new System.Drawing.Point(689, 282);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(132, 32);
            this.label21.TabIndex = 71;
            this.label21.Text = "Sokak:";
            // 
            // cmbBxCadde2
            // 
            this.cmbBxCadde2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxCadde2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbBxCadde2.FormattingEnabled = true;
            this.cmbBxCadde2.Location = new System.Drawing.Point(828, 241);
            this.cmbBxCadde2.Name = "cmbBxCadde2";
            this.cmbBxCadde2.Size = new System.Drawing.Size(194, 32);
            this.cmbBxCadde2.TabIndex = 15;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label22.Location = new System.Drawing.Point(689, 239);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(132, 32);
            this.label22.TabIndex = 69;
            this.label22.Text = "Cadde:";
            // 
            // cmbBxMahalle2
            // 
            this.cmbBxMahalle2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxMahalle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbBxMahalle2.FormattingEnabled = true;
            this.cmbBxMahalle2.Location = new System.Drawing.Point(828, 197);
            this.cmbBxMahalle2.Name = "cmbBxMahalle2";
            this.cmbBxMahalle2.Size = new System.Drawing.Size(194, 32);
            this.cmbBxMahalle2.TabIndex = 14;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label23.Location = new System.Drawing.Point(689, 196);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(132, 32);
            this.label23.TabIndex = 67;
            this.label23.Text = "Mahalle:";
            // 
            // cmbBxIlce2
            // 
            this.cmbBxIlce2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxIlce2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbBxIlce2.FormattingEnabled = true;
            this.cmbBxIlce2.Location = new System.Drawing.Point(828, 153);
            this.cmbBxIlce2.Name = "cmbBxIlce2";
            this.cmbBxIlce2.Size = new System.Drawing.Size(194, 32);
            this.cmbBxIlce2.TabIndex = 13;
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label25.Location = new System.Drawing.Point(689, 152);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(132, 32);
            this.label25.TabIndex = 65;
            this.label25.Text = "İlçe:";
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label26.Location = new System.Drawing.Point(689, 111);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(132, 32);
            this.label26.TabIndex = 64;
            this.label26.Text = "İl:";
            // 
            // cmbBxIl2
            // 
            this.cmbBxIl2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxIl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbBxIl2.FormattingEnabled = true;
            this.cmbBxIl2.Location = new System.Drawing.Point(828, 111);
            this.cmbBxIl2.Name = "cmbBxIl2";
            this.cmbBxIl2.Size = new System.Drawing.Size(194, 32);
            this.cmbBxIl2.TabIndex = 12;
            this.cmbBxIl2.SelectedIndexChanged += new System.EventHandler(this.cmbBxIl2_SelectedIndexChanged);
            // 
            // radioBtnDiger2
            // 
            this.radioBtnDiger2.AutoSize = true;
            this.radioBtnDiger2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.radioBtnDiger2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioBtnDiger2.Location = new System.Drawing.Point(118, 4);
            this.radioBtnDiger2.Name = "radioBtnDiger2";
            this.radioBtnDiger2.Size = new System.Drawing.Size(81, 29);
            this.radioBtnDiger2.TabIndex = 62;
            this.radioBtnDiger2.Text = "Diğer";
            this.radioBtnDiger2.UseVisualStyleBackColor = true;
            // 
            // radioBtnIs2
            // 
            this.radioBtnIs2.AutoSize = true;
            this.radioBtnIs2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.radioBtnIs2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioBtnIs2.Location = new System.Drawing.Point(66, 4);
            this.radioBtnIs2.Name = "radioBtnIs2";
            this.radioBtnIs2.Size = new System.Drawing.Size(46, 29);
            this.radioBtnIs2.TabIndex = 61;
            this.radioBtnIs2.Text = "İş";
            this.radioBtnIs2.UseVisualStyleBackColor = true;
            // 
            // radioBtnEv2
            // 
            this.radioBtnEv2.AutoSize = true;
            this.radioBtnEv2.Checked = true;
            this.radioBtnEv2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.radioBtnEv2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioBtnEv2.Location = new System.Drawing.Point(5, 4);
            this.radioBtnEv2.Name = "radioBtnEv2";
            this.radioBtnEv2.Size = new System.Drawing.Size(55, 29);
            this.radioBtnEv2.TabIndex = 60;
            this.radioBtnEv2.TabStop = true;
            this.radioBtnEv2.Text = "Ev";
            this.radioBtnEv2.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label27.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label27.Location = new System.Drawing.Point(687, 69);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(132, 32);
            this.label27.TabIndex = 59;
            this.label27.Text = "Adres Tipi: ";
            // 
            // txtBxEmail
            // 
            this.txtBxEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.txtBxEmail.Location = new System.Drawing.Point(467, 284);
            this.txtBxEmail.Name = "txtBxEmail";
            this.txtBxEmail.Size = new System.Drawing.Size(194, 31);
            this.txtBxEmail.TabIndex = 11;
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label29.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label29.Location = new System.Drawing.Point(343, 284);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(108, 32);
            this.label29.TabIndex = 87;
            this.label29.Text = "Email:";
            // 
            // txtBxEmail2
            // 
            this.txtBxEmail2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.txtBxEmail2.Location = new System.Drawing.Point(1149, 285);
            this.txtBxEmail2.Name = "txtBxEmail2";
            this.txtBxEmail2.Size = new System.Drawing.Size(194, 31);
            this.txtBxEmail2.TabIndex = 22;
            // 
            // label30
            // 
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label30.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label30.Location = new System.Drawing.Point(1025, 284);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(108, 32);
            this.label30.TabIndex = 89;
            this.label30.Text = "Email:";
            // 
            // label31
            // 
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label31.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label31.Location = new System.Drawing.Point(-2, 492);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(223, 40);
            this.label31.TabIndex = 91;
            this.label31.Text = "Kargo Bilgileri:";
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label32.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label32.Location = new System.Drawing.Point(219, 531);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(88, 32);
            this.label32.TabIndex = 94;
            this.label32.Text = "En(cm):";
            // 
            // label33
            // 
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label33.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label33.Location = new System.Drawing.Point(219, 497);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(124, 32);
            this.label33.TabIndex = 93;
            this.label33.Text = "Ağırlık(gr):";
            // 
            // txtBxAgirlik
            // 
            this.txtBxAgirlik.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txtBxAgirlik.Location = new System.Drawing.Point(328, 496);
            this.txtBxAgirlik.Name = "txtBxAgirlik";
            this.txtBxAgirlik.Size = new System.Drawing.Size(77, 29);
            this.txtBxAgirlik.TabIndex = 24;
            this.txtBxAgirlik.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxAgirlik_KeyPress);
            // 
            // txtBxEn
            // 
            this.txtBxEn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txtBxEn.Location = new System.Drawing.Point(328, 532);
            this.txtBxEn.Name = "txtBxEn";
            this.txtBxEn.Size = new System.Drawing.Size(77, 29);
            this.txtBxEn.TabIndex = 25;
            this.txtBxEn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxEn_KeyPress);
            // 
            // txtBxYukseklik
            // 
            this.txtBxYukseklik.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txtBxYukseklik.Location = new System.Drawing.Point(555, 530);
            this.txtBxYukseklik.Name = "txtBxYukseklik";
            this.txtBxYukseklik.Size = new System.Drawing.Size(77, 29);
            this.txtBxYukseklik.TabIndex = 27;
            this.txtBxYukseklik.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxYukseklik_KeyPress);
            // 
            // txtBxBoy
            // 
            this.txtBxBoy.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txtBxBoy.Location = new System.Drawing.Point(555, 494);
            this.txtBxBoy.Name = "txtBxBoy";
            this.txtBxBoy.Size = new System.Drawing.Size(77, 29);
            this.txtBxBoy.TabIndex = 26;
            this.txtBxBoy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxBoy_KeyPress);
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.5F);
            this.label34.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label34.Location = new System.Drawing.Point(415, 533);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(144, 32);
            this.label34.TabIndex = 99;
            this.label34.Text = "Yükseklik(cm):";
            // 
            // label35
            // 
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label35.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label35.Location = new System.Drawing.Point(415, 497);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(124, 32);
            this.label35.TabIndex = 98;
            this.label35.Text = "Boy(cm):";
            // 
            // btnHesapla
            // 
            this.btnHesapla.BackColor = System.Drawing.Color.Cornsilk;
            this.btnHesapla.FlatAppearance.BorderSize = 0;
            this.btnHesapla.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHesapla.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnHesapla.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnHesapla.Location = new System.Drawing.Point(782, 538);
            this.btnHesapla.Name = "btnHesapla";
            this.btnHesapla.Size = new System.Drawing.Size(105, 41);
            this.btnHesapla.TabIndex = 31;
            this.btnHesapla.Text = "Hesapla";
            this.btnHesapla.UseVisualStyleBackColor = false;
            this.btnHesapla.Click += new System.EventHandler(this.btnHesapla_Click);
            // 
            // txtBxDesi
            // 
            this.txtBxDesi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txtBxDesi.Location = new System.Drawing.Point(1009, 518);
            this.txtBxDesi.Name = "txtBxDesi";
            this.txtBxDesi.Size = new System.Drawing.Size(77, 29);
            this.txtBxDesi.TabIndex = 104;
            this.txtBxDesi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxDesi_KeyPress);
            // 
            // label36
            // 
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label36.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label36.Location = new System.Drawing.Point(949, 518);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(66, 32);
            this.label36.TabIndex = 103;
            this.label36.Text = "Desi:";
            // 
            // txtBxFiyat
            // 
            this.txtBxFiyat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txtBxFiyat.Location = new System.Drawing.Point(1009, 567);
            this.txtBxFiyat.Name = "txtBxFiyat";
            this.txtBxFiyat.Size = new System.Drawing.Size(77, 29);
            this.txtBxFiyat.TabIndex = 106;
            this.txtBxFiyat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBxFiyat_KeyPress);
            // 
            // label37
            // 
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label37.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label37.Location = new System.Drawing.Point(945, 567);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(66, 32);
            this.label37.TabIndex = 105;
            this.label37.Text = "Fiyat:";
            // 
            // label38
            // 
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label38.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label38.Location = new System.Drawing.Point(216, 581);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(153, 32);
            this.label38.TabIndex = 107;
            this.label38.Text = "Ödeme Bilgisi:";
            // 
            // cmbBxOdemeBilgisi
            // 
            this.cmbBxOdemeBilgisi.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxOdemeBilgisi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F);
            this.cmbBxOdemeBilgisi.FormattingEnabled = true;
            this.cmbBxOdemeBilgisi.Items.AddRange(new object[] {
            "Gönderici Ödemeli",
            "Karşı Ödemeli"});
            this.cmbBxOdemeBilgisi.Location = new System.Drawing.Point(367, 580);
            this.cmbBxOdemeBilgisi.Name = "cmbBxOdemeBilgisi";
            this.cmbBxOdemeBilgisi.Size = new System.Drawing.Size(165, 28);
            this.cmbBxOdemeBilgisi.TabIndex = 28;
            // 
            // cmbBxKargoTipi
            // 
            this.cmbBxKargoTipi.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbBxKargoTipi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F);
            this.cmbBxKargoTipi.FormattingEnabled = true;
            this.cmbBxKargoTipi.Items.AddRange(new object[] {
            "Zarf",
            "Koli",
            "Kitap"});
            this.cmbBxKargoTipi.Location = new System.Drawing.Point(6, 573);
            this.cmbBxKargoTipi.Name = "cmbBxKargoTipi";
            this.cmbBxKargoTipi.Size = new System.Drawing.Size(165, 28);
            this.cmbBxKargoTipi.TabIndex = 23;
            this.cmbBxKargoTipi.SelectedIndexChanged += new System.EventHandler(this.cmbBxKargoTipi_SelectedIndexChanged);
            // 
            // label39
            // 
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label39.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label39.Location = new System.Drawing.Point(31, 538);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(119, 32);
            this.label39.TabIndex = 109;
            this.label39.Text = "Kargo Tipi:";
            // 
            // btnOnayla
            // 
            this.btnOnayla.BackColor = System.Drawing.Color.Lime;
            this.btnOnayla.FlatAppearance.BorderSize = 0;
            this.btnOnayla.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOnayla.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.btnOnayla.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnOnayla.Location = new System.Drawing.Point(1208, 441);
            this.btnOnayla.Name = "btnOnayla";
            this.btnOnayla.Size = new System.Drawing.Size(152, 40);
            this.btnOnayla.TabIndex = 113;
            this.btnOnayla.Text = "Onayla";
            this.btnOnayla.UseVisualStyleBackColor = false;
            this.btnOnayla.Click += new System.EventHandler(this.btnOnayla_Click);
            // 
            // btnİptal
            // 
            this.btnİptal.BackColor = System.Drawing.Color.Tomato;
            this.btnİptal.FlatAppearance.BorderSize = 0;
            this.btnİptal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnİptal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.btnİptal.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnİptal.Location = new System.Drawing.Point(1208, 531);
            this.btnİptal.Name = "btnİptal";
            this.btnİptal.Size = new System.Drawing.Size(152, 45);
            this.btnİptal.TabIndex = 114;
            this.btnİptal.Text = "İptal Et";
            this.btnİptal.UseVisualStyleBackColor = false;
            this.btnİptal.Click += new System.EventHandler(this.btnİptal_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.BackColor = System.Drawing.Color.Red;
            this.btnCikis.FlatAppearance.BorderSize = 0;
            this.btnCikis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.btnCikis.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnCikis.Location = new System.Drawing.Point(1208, 579);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(152, 45);
            this.btnCikis.TabIndex = 126;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = false;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.Red;
            this.label28.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label28.Location = new System.Drawing.Point(118, 116);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(21, 27);
            this.label28.TabIndex = 127;
            this.label28.Text = "*";
            // 
            // label40
            // 
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.ForeColor = System.Drawing.Color.Red;
            this.label40.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label40.Location = new System.Drawing.Point(118, 159);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(22, 27);
            this.label40.TabIndex = 128;
            this.label40.Text = "*";
            // 
            // label41
            // 
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label41.ForeColor = System.Drawing.Color.Red;
            this.label41.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label41.Location = new System.Drawing.Point(483, 327);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(36, 27);
            this.label41.TabIndex = 129;
            this.label41.Text = "*";
            // 
            // label42
            // 
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label42.ForeColor = System.Drawing.Color.Red;
            this.label42.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label42.Location = new System.Drawing.Point(660, 157);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(21, 27);
            this.label42.TabIndex = 130;
            this.label42.Text = "*";
            // 
            // label43
            // 
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label43.Location = new System.Drawing.Point(659, 201);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(21, 27);
            this.label43.TabIndex = 131;
            this.label43.Text = "*";
            // 
            // label44
            // 
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label44.ForeColor = System.Drawing.Color.Red;
            this.label44.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label44.Location = new System.Drawing.Point(804, 116);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(21, 27);
            this.label44.TabIndex = 132;
            this.label44.Text = "*";
            // 
            // label45
            // 
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label45.ForeColor = System.Drawing.Color.Red;
            this.label45.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label45.Location = new System.Drawing.Point(805, 159);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(21, 27);
            this.label45.TabIndex = 133;
            this.label45.Text = "*";
            // 
            // label46
            // 
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label46.ForeColor = System.Drawing.Color.Red;
            this.label46.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label46.Location = new System.Drawing.Point(1168, 327);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(21, 27);
            this.label46.TabIndex = 134;
            this.label46.Text = "*";
            // 
            // label47
            // 
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label47.ForeColor = System.Drawing.Color.Red;
            this.label47.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label47.Location = new System.Drawing.Point(1340, 158);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(21, 27);
            this.label47.TabIndex = 135;
            this.label47.Text = "*";
            // 
            // label48
            // 
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label48.ForeColor = System.Drawing.Color.Red;
            this.label48.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label48.Location = new System.Drawing.Point(1340, 203);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(21, 27);
            this.label48.TabIndex = 136;
            this.label48.Text = "*";
            // 
            // label49
            // 
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label49.ForeColor = System.Drawing.Color.Red;
            this.label49.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label49.Location = new System.Drawing.Point(531, 584);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(21, 27);
            this.label49.TabIndex = 137;
            this.label49.Text = "*";
            // 
            // label53
            // 
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label53.ForeColor = System.Drawing.Color.Red;
            this.label53.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label53.Location = new System.Drawing.Point(170, 576);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(20, 20);
            this.label53.TabIndex = 304;
            this.label53.Text = "*";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioBtnDiger);
            this.panel1.Controls.Add(this.radioBtnEv);
            this.panel1.Controls.Add(this.radioBtnIs);
            this.panel1.Location = new System.Drawing.Point(141, 65);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 36);
            this.panel1.TabIndex = 306;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioBtnDiger2);
            this.panel2.Controls.Add(this.radioBtnEv2);
            this.panel2.Controls.Add(this.radioBtnIs2);
            this.panel2.Location = new System.Drawing.Point(822, 65);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 37);
            this.panel2.TabIndex = 307;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioBtnKurumsal);
            this.panel3.Controls.Add(this.radioBtnBireysel);
            this.panel3.Location = new System.Drawing.Point(449, 65);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(227, 36);
            this.panel3.TabIndex = 308;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.radioBtnKurumsal2);
            this.panel4.Controls.Add(this.radioBtnBireysel2);
            this.panel4.Location = new System.Drawing.Point(1135, 67);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(228, 36);
            this.panel4.TabIndex = 310;
            // 
            // checkBxKorumali
            // 
            this.checkBxKorumali.AutoSize = true;
            this.checkBxKorumali.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.checkBxKorumali.Location = new System.Drawing.Point(586, 569);
            this.checkBxKorumali.Name = "checkBxKorumali";
            this.checkBxKorumali.Size = new System.Drawing.Size(108, 29);
            this.checkBxKorumali.TabIndex = 29;
            this.checkBxKorumali.Text = "Korumalı";
            this.checkBxKorumali.UseVisualStyleBackColor = true;
            // 
            // checkBxSigortali
            // 
            this.checkBxSigortali.AutoSize = true;
            this.checkBxSigortali.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.checkBxSigortali.Location = new System.Drawing.Point(586, 597);
            this.checkBxSigortali.Name = "checkBxSigortali";
            this.checkBxSigortali.Size = new System.Drawing.Size(168, 29);
            this.checkBxSigortali.TabIndex = 30;
            this.checkBxSigortali.Text = "Değerli/Sigortalı";
            this.checkBxSigortali.UseVisualStyleBackColor = true;
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Text = "Baskı önizleme";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.KargoFisiYazdir_PrintPage);
            // 
            // label50
            // 
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label50.ForeColor = System.Drawing.Color.Red;
            this.label50.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label50.Location = new System.Drawing.Point(659, 241);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(21, 27);
            this.label50.TabIndex = 313;
            this.label50.Text = "*";
            // 
            // label51
            // 
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label51.ForeColor = System.Drawing.Color.Red;
            this.label51.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label51.Location = new System.Drawing.Point(1341, 243);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(21, 27);
            this.label51.TabIndex = 314;
            this.label51.Text = "*";
            // 
            // btnAlanlarıTemizle
            // 
            this.btnAlanlarıTemizle.BackColor = System.Drawing.Color.Tomato;
            this.btnAlanlarıTemizle.FlatAppearance.BorderSize = 0;
            this.btnAlanlarıTemizle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlanlarıTemizle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAlanlarıTemizle.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnAlanlarıTemizle.Location = new System.Drawing.Point(1208, 392);
            this.btnAlanlarıTemizle.Name = "btnAlanlarıTemizle";
            this.btnAlanlarıTemizle.Size = new System.Drawing.Size(152, 45);
            this.btnAlanlarıTemizle.TabIndex = 315;
            this.btnAlanlarıTemizle.Text = "Alanları Temizle";
            this.btnAlanlarıTemizle.UseVisualStyleBackColor = false;
            this.btnAlanlarıTemizle.Click += new System.EventHandler(this.btnAlanlarıTemizle_Click);
            // 
            // KargoGonder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1365, 630);
            this.Controls.Add(this.btnAlanlarıTemizle);
            this.Controls.Add(this.txtBxVg2);
            this.Controls.Add(this.txtBxVg);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.txtBxTelefon);
            this.Controls.Add(this.txtBxAdSoyad);
            this.Controls.Add(this.txtBxTelefon2);
            this.Controls.Add(this.txtBxAdSoyad2);
            this.Controls.Add(this.checkBxSigortali);
            this.Controls.Add(this.checkBxKorumali);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.btnİptal);
            this.Controls.Add(this.btnOnayla);
            this.Controls.Add(this.cmbBxKargoTipi);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.cmbBxOdemeBilgisi);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.txtBxFiyat);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.txtBxDesi);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.btnHesapla);
            this.Controls.Add(this.txtBxYukseklik);
            this.Controls.Add(this.txtBxBoy);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.txtBxEn);
            this.Controls.Add(this.txtBxAgirlik);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.txtBxEmail2);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.txtBxEmail);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtBxTc2);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.richTxtBoxAdres2);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.cmbBxSokak2);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.cmbBxCadde2);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.cmbBxMahalle2);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.cmbBxIlce2);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.cmbBxIl2);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnYazdir);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtBxTc);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.richTxtBoxAdres);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cmbBxSokak);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cmbBxCadde);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cmbBxMahalle);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbBxIlce);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cmbBxIl);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "KargoGonder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.KargoGonder_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioBtnDiger;
        private System.Windows.Forms.RadioButton radioBtnIs;
        private System.Windows.Forms.RadioButton radioBtnEv;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbBxIl;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtBxTelefon;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtBxAdSoyad;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtBxTc;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RichTextBox richTxtBoxAdres;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbBxSokak;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbBxCadde;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbBxMahalle;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbBxIlce;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnYazdir;
        private System.Windows.Forms.RadioButton radioBtnKurumsal;
        private System.Windows.Forms.RadioButton radioBtnBireysel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbBxKargoTipi;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox cmbBxOdemeBilgisi;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtBxFiyat;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtBxDesi;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btnHesapla;
        private System.Windows.Forms.TextBox txtBxYukseklik;
        private System.Windows.Forms.TextBox txtBxBoy;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtBxEn;
        private System.Windows.Forms.TextBox txtBxAgirlik;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtBxEmail2;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtBxEmail;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtBxVg2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton radioBtnKurumsal2;
        private System.Windows.Forms.RadioButton radioBtnBireysel2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtBxTelefon2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtBxAdSoyad2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtBxTc2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RichTextBox richTxtBoxAdres2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmbBxSokak2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmbBxCadde2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cmbBxMahalle2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cmbBxIlce2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cmbBxIl2;
        private System.Windows.Forms.RadioButton radioBtnDiger2;
        private System.Windows.Forms.RadioButton radioBtnIs2;
        private System.Windows.Forms.RadioButton radioBtnEv2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtBxVg;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnİptal;
        private System.Windows.Forms.Button btnOnayla;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.CheckBox checkBxSigortali;
        private System.Windows.Forms.CheckBox checkBxKorumali;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button btnAlanlarıTemizle;
    }
}

